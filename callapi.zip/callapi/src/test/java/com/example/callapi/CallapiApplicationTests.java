package com.example.callapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CallapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
